library(caret)
library(e1071)
library(forecast)

#Reading the training data
train.data <- read.csv("train.csv")

str(train.data)
head(train.data)

#Reading the test data
test.data <- read.csv("test.csv")

str(test.data)
head(test.data)
 #Finding the missing values and removing columns which have more than 55% missing data
ValueMissingVecTrain <- NA
for (i in (1:127)) ValueMissingVecTrain[i] <- sum(is.na(train.data[,i]))/nrow(train.data)
inedxMatRemove1 <- which(ValueMissingVecTrain >= 0.55)
ValueMissingVecTest <- NA
for (i in (1:127)) ValueMissingVecTest[i] <- sum(is.na(test.data[,i]))/nrow(test.data)
inedxMatRemove2 <- which(ValueMissingVecTest >= 0.55)

inedxMatRemove1
inedxMatRemove2

train.data.processed <- train.data[,-inedxMatRemove1]
test.data.processed <- test.data[,-inedxMatRemove1]

ValueMissingColTrain <- NA
for (i in (1:121)) ValueMissingColTrain[i] <- sum(is.na(train.data.processed[,i]))
inedxMatKeep1 <- which(ValueMissingColTrain > 0)

ValueMissingColText <- NA
for (i in (1:121)) ValueMissingColText[i] <- sum(is.na(test.data.processed[,i]))
inedxMatKeep2 <- which(ValueMissingColText > 0)

inedxMatKeep1
inedxMatKeep2

colnames(train.data.processed)[13]    # Continuous
paste("Number of missing value:", sum(is.na(train.data.processed[,13])))
print("--------------------------------------------------------------------------------------")
str(train.data.processed[,13])
print("--------------------------------------------------------------------------------------")

#Dealing with all the missing data
paste("MEAN  :", mean(train.data.processed[,13], na.rm = TRUE))
paste("MEDIAN:", median(train.data.processed[,13], na.rm = TRUE))
paste("MAX   :", max(train.data.processed[,13], na.rm = TRUE))
paste("MIN   :", min(train.data.processed[,13], na.rm = TRUE))

# most value is around 0.06, less than 0.1
# we choose Average as missing value
train.data.processed.filling <- train.data.processed
test.data.processed.filling <- test.data.processed
train.data.processed.filling[,13][is.na(train.data.processed.filling[,13])] <- 0.078
test.data.processed.filling[,13][is.na(test.data.processed.filling[,13])] <- 0.078

colnames(train.data.processed)[16]    # Continuous
paste("Number of missing value:", sum(is.na(train.data.processed[,16])))
print("--------------------------------------------------------------------------------------")
str(train.data.processed[,16])
print("--------------------------------------------------------------------------------------")

paste("MEAN  :", mean(train.data.processed[,16], na.rm = TRUE))
paste("MEDIAN:", median(train.data.processed[,16], na.rm = TRUE))
paste("MAX   :", max(train.data.processed[,16], na.rm = TRUE))
paste("MIN   :", min(train.data.processed[,16], na.rm = TRUE))
percentage_0 <- length(which(train.data.processed[,16] == 0)) / length(which(!is.na(train.data.processed[,16])))
paste("Percentage of Value 0:", paste(percentage_0*100, "%", sep=''))

# more than 84% of column 16 is 0, we choose 0 as missing value
train.data.processed.filling[,16][is.na(train.data.processed.filling[,16])] <- 0
test.data.processed.filling[,16][is.na(test.data.processed.filling[,16])] <- 0

colnames(train.data.processed)[18]    # Continuous
paste("Number of missing value:", sum(is.na(train.data.processed[,18])))
print("--------------------------------------------------------------------------------------")
str(train.data.processed[,18])
print("--------------------------------------------------------------------------------------")

paste("MEAN  :", mean(train.data.processed[,18], na.rm = TRUE))
paste("MEDIAN:", median(train.data.processed[,18], na.rm = TRUE))
paste("MAX   :", max(train.data.processed[,18], na.rm = TRUE))
paste("MIN   :", min(train.data.processed[,18], na.rm = TRUE))

# 18 column is Continuous from 0 to 1, we choose average as missing value
train.data.processed.filling[,18][is.na(train.data.processed.filling[,18])] <- 0.36
test.data.processed.filling[,18][is.na(test.data.processed.filling[,18])] <- 0.36

colnames(train.data.processed)[30]    # Continuous
paste("Number of missing value:", sum(is.na(train.data.processed[,30])))
print("--------------------------------------------------------------------------------------")
str(train.data.processed[,30])
print("--------------------------------------------------------------------------------------")

paste("MEAN  :", mean(train.data.processed[,30], na.rm = TRUE))
paste("MEDIAN:", median(train.data.processed[,30], na.rm = TRUE))
paste("MAX   :", max(train.data.processed[,30], na.rm = TRUE))
paste("MIN   :", min(train.data.processed[,30], na.rm = TRUE))
percentage_0.01 <- length(which(train.data.processed[,30] < 0.01)) / length(which(!is.na(train.data.processed[,30])))
paste("Percentage of Value less than 0.01:", paste(percentage_0.01*100, "%", sep=''))

# more than 98% of column 30 is less than 0.01, we choose 0 as missing value
train.data.processed.filling[,30][is.na(train.data.processed.filling[,30])] <- 0
test.data.processed.filling[,30][is.na(test.data.processed.filling[,30])] <- 0

colnames(train.data.processed)[35]    # Continuous
paste("Number of missing value:", sum(is.na(train.data.processed[,35])))
print("--------------------------------------------------------------------------------------")
str(train.data.processed[,35])
print("--------------------------------------------------------------------------------------")

paste("MEAN  :", mean(train.data.processed[,35], na.rm = TRUE))
paste("MEDIAN:", median(train.data.processed[,35], na.rm = TRUE))
paste("MAX   :", max(train.data.processed[,35], na.rm = TRUE))
paste("MIN   :", min(train.data.processed[,35], na.rm = TRUE))

# MEAN and MEDIAN is similiar, column 35 has Continuous data between 0 to 1
# we choose median as missing value
train.data.processed.filling[,35][is.na(train.data.processed.filling[,35])] <- 0.46
test.data.processed.filling[,35][is.na(test.data.processed.filling[,35])] <- 0.46

colnames(train.data.processed)[36]    # Continuous
paste("Number of missing value:", sum(is.na(train.data.processed[,35])))
print("--------------------------------------------------------------------------------------")
str(train.data.processed[,36])
print("--------------------------------------------------------------------------------------")

paste("MEAN  :", mean(train.data.processed[,36], na.rm = TRUE))
paste("MEDIAN:", median(train.data.processed[,36], na.rm = TRUE))
paste("MAX   :", max(train.data.processed[,36], na.rm = TRUE))
paste("MIN   :", min(train.data.processed[,36], na.rm = TRUE))

# MEAN and MEDIAN is similiar, column 36 has Continuous data between 0 to 1
# we choose median as missing value
train.data.processed.filling[,36][is.na(train.data.processed.filling[,36])] <- 0.44
test.data.processed.filling[,36][is.na(test.data.processed.filling[,36])] <- 0.44

colnames(train.data.processed)[37]    # Discrete
paste("Number of missing value:", sum(is.na(train.data.processed[,37])))
print("--------------------------------------------------------------------------------------")
str(train.data.processed[,37])
print("--------------------------------------------------------------------------------------")

paste("MEAN  :", mean(train.data.processed[,37], na.rm = TRUE))
paste("MEDIAN:", median(train.data.processed[,37], na.rm = TRUE))
paste("MAX   :", max(train.data.processed[,37], na.rm = TRUE))
paste("MIN   :", min(train.data.processed[,37], na.rm = TRUE))
b <- table(train.data.processed[,37])
paste("MODE  :", as.numeric(names(b)[b == max(b)]))

# Column 37 is discrete, range between 0 to 240
# we choose to set Mode "1" as the missing value, because its repetition rate is high
train.data.processed.filling[,37][is.na(train.data.processed.filling[,37])] <- 1
test.data.processed.filling[,37][is.na(test.data.processed.filling[,37])] <- 1

train.data.processed.convert <- train.data.processed.filling
test.data.processed.convert <- test.data.processed.filling

train.data.processed.convert[,3] <- as.numeric(train.data.processed.convert[,3])
test.data.processed.convert[,3] <- as.numeric(test.data.processed.convert[,3])

train.data.processed.convert <- train.data.processed.convert[,-1]
test.data.processed.convert <- test.data.processed.convert[,-1]

str(train.data.processed.convert)

train.data.cat <- train.data.processed.convert
test.data.cat <- test.data.processed.convert

#Dealing with categorical columns
categorical.names <- c(paste("Product_Info_", c(1:3,5:7),sep=""), paste("Employment_Info_", c(2,3,5), sep=""), paste("InsuredInfo_", 1:7, sep=""), paste("Insurance_History_", c(1:4,7:9), sep=""), paste("Family_Hist_1"),paste("Medical_History_", c(2:9, 11:14, 16:23, 25:31, 33:41),sep=""))


for(i in categorical.names) train.data.cat[,i]<-as.factor(train.data.cat[,i])
for(i in categorical.names) test.data.cat[,i]<-as.factor(test.data.cat[,i])
str(train.data.cat)

train.data.binary <- train.data.cat
test.data.binary <- test.data.cat
categorical.indexes <- c(1:3, 5:7, 13, 14, 16, 18:28, 30:33, 37:72)

for(i in categorical.indexes){
  v_ <- train.data.binary[,i]
  newdf <- model.matrix(~v_-1,data=train.data.binary)
  colnames(newdf) <- paste(colnames(train.data.binary)[i], c(colnames(newdf)), sep = "_")
  train.data.binary <- data.frame(train.data.binary, newdf)
}

rm(v_)

for(m in categorical.indexes){
  v_ <- test.data.binary[,m]
  newdf1 <- model.matrix(~v_-1,data=test.data.binary)
  colnames(newdf1) <- paste(colnames(test.data.binary)[m], c(colnames(newdf1)), sep = "_")
  test.data.binary <- data.frame(test.data.binary, newdf1)
}

train.data.binary <- train.data.binary[,-categorical.indexes]
test.data.binary <- test.data.binary[,-categorical.indexes]
str(train.data.binary)

str(test.data.binary)

#Using LDA to find the significant columns needed for neural networks
r.lda <- lda(formula = Response ~ ., data = train.data.binary)
covariable <- (r.lda$scaling)%*%(r.lda$svd/sum(r.lda$svd))
covariable[(abs(covariable) > 1.8),]
names <- c("Ht", "Wt", "BMI", "Product_Info_3_v_34", "Medical_History_2_v_73", 
           "Medical_History_2_v_142", "Medical_History_2_v_148", "Medical_History_2_v_209", 
           "Medical_History_2_v_216", "Medical_History_2_v_243", "Medical_History_2_v_267", 
           "Medical_History_2_v_346", "Medical_History_5_v_3", "Response")
train.data.binary[, names]

#reading the finaltraining dataset from the csv
prudentialData <- read.csv(file="FinalPru3000.csv", header=TRUE, sep= ',')

#Selecting the Max and the Min from the datasets
index <- sample(1:nrow(prudentialData),round(0.80*nrow(prudentialData)))
maxs <- apply(prudentialData, 2, max)
maxs <- round(maxs, digits = 0)
mins <- apply(prudentialData, 2, min)
mins <- round(mins, digits = 0)
maxs

#Scaling the data to better fit the model
scaled <- as.data.frame(scale(prudentialData, center = mins, scale = maxs - mins))
#newscaled <- cbind(scaled, prudentialData[,13])
#apply(scaled,2,function(x) sum(is.na(x)))
scaled[is.na(scaled)] <- 0

#Dividing into the training and test dataset
train_ <- scaled[index,]
test_ <- scaled[-index,]

#Building the neural network model
library(neuralnet)
n <- names(train_)
f <- as.formula(paste("Response ~", paste(n[!n %in% "Response"], collapse = " + ")))
nn <- neuralnet(f,data=train_,hidden=c(4,4),linear.output=T,stepmax = 1e6)
plot(nn)

#Predicting the values 
pr.nn <- compute(nn,test_[,1:12])
pr.nn_ <- pr.nn$net.result*(max(prudentialData$Response)-min(prudentialData$Response))+min(prudentialData$Response)
test.r <- (test_$Response)*(max(prudentialData$Response)-min(prudentialData$Response))+min(prudentialData$Response)
plot(test.r)

#Finding the Mean Square Error between the actual and the predicted values
MSE.nn <- sum((test.r - pr.nn_)^2)/nrow(test_)
MSE.nn

accuracy(prudentialData[8000:10000,13],test.r)

#Plotting the the graph of the predicted values
par(mfrow=c(1,2))
plot(test_$Response,pr.nn_,col='blue',main='Real vs predicted NN',pch=18,cex=0.7)
abline(0,1,lwd=2)
legend('bottomright',legend='NN',pch=18,col='blue', bty='n')
