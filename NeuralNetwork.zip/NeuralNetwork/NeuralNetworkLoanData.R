#Loan Dataset:
  
install.packages("neuralnet")
library("neuralnet")
mydata <- read.csv("D:/ADS/NN/loan.csv")

Res_status <- as.numeric(mydata$Res_status)-1
Occupation <- as.numeric(mydata$Occupation)-1
Job_status <- as.numeric(mydata$Job_status)-1
Liab_ref <- as.numeric(mydata$Liab_ref)	-1
Acc_ref <- as.numeric(mydata$Acc_ref)-1
Decision <- as.numeric(mydata$Decision)-1

input_data <-data.frame(Res_status,Occupation,Job_status,Liab_ref,Acc_ref)
maxs_ <- apply(input_data, 2, max) 
mins_ <- apply(input_data, 2, min)

scaled <- as.data.frame(scale(input_data, center = mins_, scale = maxs_ - mins_))
scaled



final_data = cbind(scaled,Decision)
final_data
library(caTools)
set.seed(101)

# Create Split (any column is fine)
split = sample.split(final_data$Decision, SplitRatio = 0.80)

# Split based off of split Boolean Vector
train = subset(final_data, split == TRUE)
test = subset(final_data, split == FALSE)



feats <- names(scaled)

# Concatenate strings
f <- paste(feats,collapse=' + ')
f <- paste('Decision ~',f)

# Convert to formula
f <- as.formula(f)

f

install.packages('neuralnet')
library(neuralnet)
n<- names(train)
f <- as.formula(paste("Decision ~", paste(n[!n %in% "Decision"],collapse =" + ")))

nnet <- neuralnet(f,data=train,hidden=c(4,2),threshold=0.03,linear.output=FALSE)
plot(nnet)

# Compute Predictions off Test Set
pr.nn <- compute(nnet,test[,1:5])
head(test)

pr.nn_ <- pr.nn$net.result*(max(final_data$Decision)-min(final_data$Decision))+min(final_data$Decision)
test.r <- (test$Decision)*(max(final_data$Decision)-min(final_data$Decision))+min(final_data$Decision)

#Finding the MSE value 
MSE.nn <- sum((test.r - pr.nn_)^2)/nrow(test)

print(MSE.nn)
##[1] 0.296339991



