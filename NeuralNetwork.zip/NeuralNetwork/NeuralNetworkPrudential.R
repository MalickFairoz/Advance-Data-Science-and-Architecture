

#Prudential dataset:

install.packages("caTools")
install.packages("ade4")
install.packages("forecast")
install.packages("utility")
install.packages("readr")
library(forecast)
library(caret)
library(ade4)
library(randomForest)
library(caTools)
library(e1071)
library(rpart)
library(ggplot2)
library(rattle)
library(readr)
library(utility)

#loading the train data
prudential_train_Data <- read.csv(file="D:/ADS/NN/train.csv", header=TRUE, sep= ',')

#counting number of nulls in each column
count_null_columns <- sapply(prudential_train_Data, function(x) sum(is.na(x)))
count_null_columns[count_null_columns > nrow(prudential_train_Data)*0.4]
#removing columns with more than 40% if null values
Filtered_Data <- prudential_train_Data[,-c(30,35,36,38,48,53,62,70)]


#removing outliers
model = lm(Response~. , data = Filtered_Data)
cooksd <- cooks.distance(model)
plot(cooksd, pch="*", cex=2, main="Influential Obs by Cooks distance")  # plot cook's distance
abline(h = 4*mean(cooksd, na.rm=T), col="red")  # add cutoff line
text(x=1:length(cooksd)+1, y=cooksd, labels=ifelse(cooksd>4*mean(cooksd, na.rm=T),names(cooksd),""), col="red")

influential <- as.numeric(names(cooksd)[(cooksd > 4*mean(cooksd, na.rm=T))])  # influential row numbers
influencers <- Filtered_Data[influential, ] #influential observations
Filtered_Data_new<- Filtered_Data[-influential, ]



#replacing null values with mean
for(i in 1:ncol(Filtered_Data_new))
{
  if(is.numeric(Filtered_Data_new[,i])) {
    Filtered_Data_new[is.na(Filtered_Data_new[,i]),i] <- mean(Filtered_Data_new[!is.na(Filtered_Data_new[,i]),i])
  }
}

# Removing variable with near to Zero variance 
nzv <- nearZeroVar(Filtered_Data_new, saveMetrics = FALSE)
Filtered_Data_new <- Filtered_Data_new[,-nzv]


#variable selection
lm_one <- lm(Response ~ Ins_Age,data=Filtered_Data_new)
lm_all <- lm(Response ~ .,data=Filtered_Data_new)
step(lm_one,scope=list(upper=lm_all, lower= lm_one), direction = "both",trace = 1)

Filtered_new <- Filtered_Data_new[,c("Ins_Age" , "BMI" , "Medical_History_4" , "Medical_History_39" , 
                                     "Medical_History_23" , "Product_Info_4" , "Medical_History_13" , 
                                     "InsuredInfo_6" , "Medical_History_18" , 
                                     "Medical_Keyword_23" , "Family_Hist_4" , "Medical_History_28" , 
                                     "Medical_History_3" , "Employment_Info_3" , "Medical_History_1" , 
                                     "Insurance_History_1" , "Medical_Keyword_48" , "Medical_Keyword_37" , 
                                     "Medical_Keyword_25" , "Product_Info_3" , "InsuredInfo_1" , "Medical_History_21" , 
                                     "Medical_History_41" , "Medical_History_12" , "Product_Info_6" , 
                                     "Medical_History_37" , "Medical_History_2" , "Product_Info_2" , 
                                     "Family_Hist_1" , "Insurance_History_8","Response")]


set.seed(123)
index = sample(seq_len(nrow(Filtered_new)), size = floor(0.8*nrow(Filtered_new)))
train_data <- Filtered_new[index, ]
test_data <- Filtered_new[-index, ]
write.csv(train_data, file = "D:/ADS/NN/Filtered_data.csv", row.names = FALSE)

filter_data <- read.csv(file="D:/ADS/NN/Filtered_data.csv", header=TRUE, sep= ',')

data <- filter_data[,c("Medical_History_41","Product_Info_3", "Insurance_History_1",
                       "Employment_Info_3", "Medical_History_3", "InsuredInfo_6",
                       "Medical_History_13","Medical_History_23", "Medical_History_39",
                       "Medical_History_4", "Medical_Keyword_25", "Medical_Keyword_37",
                       "Medical_Keyword_48", "Medical_History_1","Family_Hist_4",
                       "Medical_Keyword_23", "Product_Info_4" , "BMI" , "Ins_Age" , "Response")]
#scaling the data
maxs <- apply(data, 2, max) 
mins <- apply(data, 2, min)

scaled <- as.data.frame(scale(data, center = mins, scale = maxs - mins))

#splitting the scaled data
set.seed(500)
index <- sample(1:nrow(data),round(0.8*nrow(data)))
train_ <- scaled[index,]
test_ <- scaled[-index,]


n <- names(train_)
f <- as.formula(paste("Response ~", paste(n[!n %in% "Response"], collapse = " + ")))
f
nn <- neuralnet(f,data=train_,hidden=c(10,6,3),threshold = 0.5, linear.output=FALSE)

plot(nn)

#predicting output
pr.nn <- compute(nn,test_[,1:19])
pr.nn_ <- pr.nn$net.result*(max(data$Response)-min(data$Response))+min(data$Response)
test.r <- (test_$Response)*(max(data$Response)-min(data$Response))+min(data$Response)
MSE.nn <- sum((test.r - pr.nn_)^2)/nrow(test_)
print(MSE.nn)
#[1] 3.670547408
